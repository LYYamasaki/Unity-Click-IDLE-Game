using UnityEngine;

public class InimigoSpawner : MonoBehaviour
{
    public GameObject prefabDoInimigo;

    // ---- NOVA VARIÁVEL ----
    // Vamos arrastar nosso objeto "PontoDeSpawn" para este campo no Inspector
    public Transform pontoDeSpawn;

    void Start()
    {
        // Spawna o primeiro inimigo
        SpawnNovoInimigo();
    }

    public void SpawnNovoInimigo()
    {
        // ---- LINHA MODIFICADA ----
        // Em vez de Vector3.zero, agora usamos a posição do nosso marcador
        Instantiate(prefabDoInimigo, pontoDeSpawn.position, Quaternion.identity);
    }

    public void IniciarRespawnComAtraso(float atraso)
    {
        Invoke("SpawnNovoInimigo", atraso);
    }
}