using UnityEngine;
using UnityEngine.EventSystems;

public class InimigoClicavel : MonoBehaviour
{
    public int vida = 10;

    private Animator animator;
    private Collider2D colisor;
    private bool estaMorto = false;
    private InimigoSpawner spawner;

    void Start()
    {
        animator = GetComponent<Animator>();
        colisor = GetComponent<Collider2D>();
        spawner = FindObjectOfType<InimigoSpawner>();
    }

    void Update()
    {
        if (estaMorto) return;

        if (Input.GetMouseButtonDown(0))
        {
            if (EventSystem.current.IsPointerOverGameObject()) return;

            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

            if (hit.collider != null && hit.collider.gameObject == gameObject)
            {
                // Agora o dano vem do GameManager!
                vida -= (int)GameManager.instance.danoPorClique;
                Debug.Log("Slime clicado! Vida restante: " + vida);

                if (vida <= 0)
                {
                    MorteDoInimigo();
                }
                else
                {
                    animator.SetTrigger("TomouDano");
                }
            }
        }
    }

    private void MorteDoInimigo()
    {
        estaMorto = true;
        colisor.enabled = false;
        animator.SetTrigger("Morreu");

        // --- A GRANDE MUDANÇA ESTÁ AQUI ---
        // Avisa o GameManager para nos dar a recompensa
        GameManager.instance.RecompensaPorMonstro();

        if (spawner != null)
        {
            spawner.IniciarRespawnComAtraso(0.5f);
        }

        Destroy(gameObject, 0.5f);
    }
}