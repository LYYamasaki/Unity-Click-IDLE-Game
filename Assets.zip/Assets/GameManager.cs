using UnityEngine;
using UnityEngine.UI; // Mantido para compatibilidade, mas vamos usar TMPro
using TMPro; // Essencial para usar TextMeshPro

public class GameManager : MonoBehaviour
{
    // A instância estática permite acesso fácil de qualquer outro script
    public static GameManager instance;

    // --- Variáveis do Jogador ---
    public long moedas;
    public long danoPorClique = 1;
    public long custoUpgradeAtaque = 15;

    // --- Referências de Objetos da Cena ---
    public GameObject janelaDeUpgrades;

    // --- Variáveis da UI (Interface do Usuário) ---
    // É recomendado usar TextMeshProUGUI para melhor qualidade visual
    public Text moedasText;
    public Text textoCustoUpgradeAtaque;


    private void Awake()
    {
        // Configuração correta do Singleton
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
            return; // Retorna para não executar o resto do código
        }

        // Carrega o progresso salvo ao iniciar
        CarregarProgresso();
    }

    // Função para abrir/fechar a janela de upgrades
    public void ToggleJanelaUpgrades()
    {
        if (janelaDeUpgrades != null)
        {
            // A função SetActive já faz a verificação, podemos simplificar:
            janelaDeUpgrades.SetActive(!janelaDeUpgrades.activeSelf);
        }
    }

    // Função do upgrade de ataque
    public void ComprarUpgradeAtaque()
    {
        if (moedas >= custoUpgradeAtaque)
        {
            moedas -= custoUpgradeAtaque;
            danoPorClique *=2;
            custoUpgradeAtaque *= 2; // Custo duplica a cada compra
            AtualizarUI();
            Debug.Log("Upgrade de Ataque comprado! Dano por clique: " + danoPorClique);
        }
    }

    // Função que é chamada pelo inimigo quando ele morre
    public void RecompensaPorMonstro()
    {
        moedas += 10;
        AtualizarUI();
        Debug.Log("Monstro derrotado! Você ganhou 10 moedas!");
    }

    // Função para atualizar toda a UI de uma vez
    public void AtualizarUI()
    {
        if (moedasText != null)
        {
            moedasText.text = FormatarNumero(moedas);
        }
        if (textoCustoUpgradeAtaque != null)
        {
            textoCustoUpgradeAtaque.text = FormatarNumero(custoUpgradeAtaque);
        }
    }

    // Função para formatar números grandes com abreviações
    private string FormatarNumero(long numero)
    {
        if (numero < 1000) return numero.ToString();
        if (numero < 1000000) return (numero / 1000f).ToString("F2") + " K";
        if (numero < 1000000000) return (numero / 1000000f).ToString("F2") + " M";
        if (numero < 1000000000000) return (numero / 1000000000f).ToString("F2") + " B";
        if (numero < 1000000000000000) return (numero / 1000000000000f).ToString("F2") + " T";
        if (numero < 1000000000000000000) return (numero / 1000000000000000f).ToString("F2") + " Q";
        return numero.ToString("E2");
    }

    // Funções de Salvar e Carregar
    public void SalvarProgresso()
    {
        PlayerPrefs.SetString("MoedasSalvas", moedas.ToString());
        PlayerPrefs.SetString("DanoSalvo", danoPorClique.ToString());
        PlayerPrefs.SetString("CustoUpgradeAtaqueSalvo", custoUpgradeAtaque.ToString());
        PlayerPrefs.Save();
        Debug.Log("Progresso salvo!");
    }

    // Esta função estava faltando no seu script
    public void CarregarProgresso()
    {
        moedas = long.Parse(PlayerPrefs.GetString("MoedasSalvas", "0"));
        danoPorClique = long.Parse(PlayerPrefs.GetString("DanoSalvo", "1"));
        custoUpgradeAtaque = long.Parse(PlayerPrefs.GetString("CustoUpgradeAtaqueSalvo", "15"));
        AtualizarUI(); // Atualiza a UI com os valores carregados
        Debug.Log("Progresso carregado!");
    }
}
